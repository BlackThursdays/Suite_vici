<?php
$mod_strings['fieldTypes']['new_phone'] = 'Расширенный телефон';
?>
