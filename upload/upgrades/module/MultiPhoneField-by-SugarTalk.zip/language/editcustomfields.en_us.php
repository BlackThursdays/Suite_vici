<?php
$mod_strings['NEW_PHONE_IS_BY_DEFAULT'] = 'Telephone number cannot set by default';
$mod_strings['NEW_PHONE_IS_NOT_REPORTABLE'] = 'Telephone fields are not available in Reports';
$mod_strings['NEW_PHONE_IS_NOT_IMPORTABLE'] = 'Telephone fields are not importable';
$mod_strings['NEW_PHONE_IS_NOT_MERGEABLE'] = 'Telephone fields can not be merged';
?>
