<?php
$mod_strings['fieldTypes']['new_phone'] = 'Extended Phone';
?>
