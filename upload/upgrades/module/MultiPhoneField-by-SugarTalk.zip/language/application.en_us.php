<?php
$app_strings['LBL_PHONE_MAIN'] = 'Main';
$app_strings['LBL_PHONE_DONT_CALL'] = 'Dont call';
$app_strings['LBL_TYPE_PHONE'] = 'Phone type';

$app_list_strings['phone_type_dom']['private'] = 'Private';
$app_list_strings['phone_type_dom']['mobile'] = 'Mobile';
$app_list_strings['phone_type_dom']['work'] = 'Work';
$app_list_strings['phone_type_dom']['fax'] = 'Fax';

?>
