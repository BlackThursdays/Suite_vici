<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_C_CASHES_LEADS_FROM_LEADS_TITLE'] = 'Предварит. контакты';
