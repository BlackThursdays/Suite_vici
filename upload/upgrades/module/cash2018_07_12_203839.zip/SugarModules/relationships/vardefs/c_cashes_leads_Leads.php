<?php
// created: 2018-07-12 20:38:39
$dictionary["Lead"]["fields"]["c_cashes_leads"] = array (
  'name' => 'c_cashes_leads',
  'type' => 'link',
  'relationship' => 'c_cashes_leads',
  'source' => 'non-db',
  'module' => 'c_cashes',
  'bean_name' => 'c_cashes',
  'side' => 'right',
  'vname' => 'LBL_C_CASHES_LEADS_FROM_C_CASHES_TITLE',
);
